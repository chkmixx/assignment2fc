﻿using Xunit;
using assignment2fc;

namespace assignment2fc.Tests
{
    public class CallPricingTests
    {
        [Fact]
        public void KzNonRoaming_Returns15PerMinute()
        {
            var record = new CallRecord("001", "KZ", 4, false);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(60.00m, result);
        }

        [Fact]
        public void KzRoamingUnderOneMinute_Returns50()
        {
            var record = new CallRecord("002", "KZ", 0.5, true);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(50.00m, result);
        }

        [Fact]
        public void RoamingTenMinutes_Returns120PerMinute()
        {
            var record = new CallRecord("003", "US", 10, true);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(1200.00m, result);
        }

        [Fact]
        public void OtherCall_Returns45PerMinute()
        {
            var record = new CallRecord("004", "DE", 3, false);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(135.00m, result);
        }
    
            [Fact]
        public void UnknownCountryNonRoaming_Returns45PerMinute()
        {
            var record = new CallRecord("005", "XX", 2, false);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(90.00m, result);
        }

        [Fact]
        public void KzRoamingOneMinute_Returns45()
        {
            var record = new CallRecord("006", "KZ", 1, true);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(45.00m, result);
        }

        [Fact]
        public void ZeroMinuteNonRoaming_ReturnsZero()
        {
            var record = new CallRecord("007", "US", 0, false);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(0.00m, result);
        }

        [Fact]
        public void RoamingJustBelowTenMinutes_UsesFallbackRate()
        {
            var record = new CallRecord("008", "US", 9.999, true);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(449.96m, result);
        }

        [Fact]
        public void RoamingAtTenMinutes_Uses120Rate()
        {
            var record = new CallRecord("009", "US", 10, true);

            var result = CallPricing.CalculateCost(in record);

            Assert.Equal(1200.00m, result);
        }
    }
    }