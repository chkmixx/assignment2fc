﻿using System;
using Xunit;
using assignment2fc;

namespace assignment2fc.Tests
{
    public class ValidationTests
    {
        [Fact]
        public void EmptyRecordId_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("", "KZ", 5, false));
        }

        [Fact]
        public void EmptyCountry_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("001", "", 5, false));
        }

        [Fact]
        public void NegativeDuration_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("001", "KZ", -1, false));
        }

        [Fact]
        public void TooLongDuration_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("001", "KZ", 10001, false));
        }

        [Fact]
        public void InfinityDuration_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("001", "KZ", double.PositiveInfinity, false));
        }

        [Fact]
        public void NaNDuration_ThrowsException()
        {
            Assert.Throws<ArgumentException>(() =>
                new CallRecord("001", "KZ", double.NaN, false));
        }

        [Fact]
        public void DefaultCallRecord_ThrowsException()
        {
            var record = default(CallRecord);

            Assert.Throws<ArgumentException>(() =>
                CallPricing.CalculateCost(in record));
        }
    }
}