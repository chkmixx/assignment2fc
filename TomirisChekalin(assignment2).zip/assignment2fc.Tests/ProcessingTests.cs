﻿using System;
using Xunit;
using assignment2fc;

namespace assignment2fc.Tests
{
    public class ProcessingTests
    {
        [Fact]
        public void SequentialAndParallel_ReturnSameResult()
        {
            var records = new[]
            {
                new CallRecord("001", "KZ", 4, false),
                new CallRecord("002", "KZ", 0.5, true),
                new CallRecord("003", "US", 10, true),
                new CallRecord("004", "DE", 3, false),
                new CallRecord("005", "XX", 2, false),
                new CallRecord("006", "KZ", 1, true)
            };

            var sequential = CallProcessor.ProcessCallsSequential(records);
            var parallel = CallProcessor.ProcessCallsParallel(records);

            Assert.Equal(sequential, parallel);
        }

        [Fact]
        public void EmptyArray_ReturnsZero()
        {
            var records = Array.Empty<CallRecord>();

            var sequential = CallProcessor.ProcessCallsSequential(records);
            var parallel = CallProcessor.ProcessCallsParallel(records);

            Assert.Equal(0m, sequential);
            Assert.Equal(0m, parallel);
        }

        [Fact]
        public void OddLengthArray_ThrowsException()
        {
            var records = new[]
            {
                new CallRecord("001", "KZ", 1, false),
                new CallRecord("002", "KZ", 2, false),
                new CallRecord("003", "KZ", 3, false)
            };

            Assert.Throws<ArgumentException>(() =>
                CallProcessor.ProcessCallsParallel(records));
        }
        [Fact]
        public void NullArray_ThrowsException()
        {
            Assert.Throws<ArgumentNullException>(() =>
                CallProcessor.ProcessCallsParallel(null));
        }

        [Fact]
        public void ThousandRecords_ReturnSameResult()
        {
            var records = new CallRecord[1000];

            for (int i = 0; i < records.Length; i++)
            {
                records[i] = new CallRecord(
                    i.ToString(),
                    "KZ",
                    2,
                    false);
            }

            var sequential = CallProcessor.ProcessCallsSequential(records);
            var parallel = CallProcessor.ProcessCallsParallel(records);

            Assert.Equal(sequential, parallel);
        }

        [Fact]
        public void ParallelProcessing_Works100Times()
        {
            var records = new[]
            {
                new CallRecord("001", "KZ", 4, false),
                new CallRecord("002", "US", 10, true),
                new CallRecord("003", "DE", 3, false),
                new CallRecord("004", "KZ", 1, true)
            };

            var expected = CallProcessor.ProcessCallsSequential(records);

            for (int i = 0; i < 100; i++)
            {
                var result = CallProcessor.ProcessCallsParallel(records);

                Assert.Equal(expected, result);
            }
        }

        [Fact]
        public void InputRecords_RemainUnchanged()
        {
            var records = new[]
            {
                new CallRecord("001", "KZ", 4, false),
                new CallRecord("002", "US", 10, true)
            };

            var before = records;

            CallProcessor.ProcessCallsParallel(records);

            Assert.Equal(before, records);
        }
    }
}