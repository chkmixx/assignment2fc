Student:Tomiris Chekalin
Group:IT-2503
Analysis

The application consists of a main project and a test project.

CallRecord is responsible for storing and validating call data.
CallPricing contains the tariff calculation.
CallProcessor contains sequential and parallel processing.
Program.cs runs a simple example and compares the results.

The main goal is to calculate call costs without changing the input records.

Race condition analysis

A shared variable such as globalCallCounter++ can cause a race condition when two threads access it at the same time.

The increment operation is not a single indivisible operation. Two threads can read the same value and one update can be lost.

The solution uses separate output arrays for each thread instead of a shared counter.
Test results

22 tests passed and 0 tests failed.

The tests cover:
- tariff rules
- invalid input
- boundary cases
- zero-minute calls
- default CallRecord
- empty and odd-length arrays
- null input
- 1000 records
- sequential and parallel results
- repeated parallel execution
- unchanged input records
